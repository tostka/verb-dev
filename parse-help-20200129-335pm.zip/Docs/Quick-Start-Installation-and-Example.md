# Installing VERB-dev

    # Install VERB-dev from the Powershell Gallery
    Find-Module VERB-dev | Install-Module
